Fall Protection Competent Person — narration audio
Files are named <storyboard screen code>_<order>_<character>.mp3 and match the storyboard's Narration rows.
narration-index.csv lists every file with its character, voice, length and script.
Voices: Kokoro-82M neural TTS (Apache-2.0), generated offline; casting in tools/voices.json.
Storyline 360: Insert > Audio > Audio from File (one clip per slide/layer). Rise 360: Multimedia > Audio block.
