Voice auditions — Fall Protection Competent Person

Each character reads one real line in four candidate voices. Option A is the voice used in the course now.
To change a voice: edit tools/voices.json (voice name shown in the file name) and rerun tools/build-audio.py.

Tasha — Narrator and lead hand. Warm, confident, natural pace.
  A. af_heart  (current)
  B. af_bella
  C. af_sarah
  D. af_nicole

Ray — Foreman, 28 years in. Lower, slower, weathered.
  A. am_fenrir  (current)
  B. am_onyx
  C. am_eric
  D. am_liam

Marco — Superintendent. Measured, businesslike.
  A. am_michael  (current)
  B. am_eric
  C. am_liam
  D. am_puck

Dee — Second-year apprentice. Younger, a touch quicker.
  A. af_bella  (current)
  B. af_sky
  C. af_nova
  D. af_jessica

Luis — Fall survivor. Quiet, slower, reflective.
  A. am_puck  (current)
  B. am_echo
  C. am_eric
  D. am_michael
